<?php 
global $wp;
?>

<div id="secure-plugin-form-data"></div>
    <form method="post" id="secure-lpugin-form">
        <input type="text" id="name" name="name">
        <input type="email" id="wm_email" name="wm_email">
        <textarea name="message" id="message" ></textarea>
        <input type="submit" name="submit" value="Submit">
    </form>
