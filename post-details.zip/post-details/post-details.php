<?php   

/**
 * Plugin Name: Post Details
 * Description: A simple plugin to display post details.
 * Version: 1.0
 * Author: Samir
 * Author URI: https://mashiuzzaman.com
**/

if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}



class PostDetails{
    public function __construct(){
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
    }

    public function enqueue_styles() {
        wp_enqueue_style( 
            'post-details-style', 
            plugin_dir_url( __FILE__ ) . 'assets/css/style.css',
            array(),
            '1.0.0',
            'all' 
        );
    }
}

new PostDetails();