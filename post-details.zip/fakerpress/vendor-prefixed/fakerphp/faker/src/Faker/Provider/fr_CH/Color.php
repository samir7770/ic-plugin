<?php

namespace FakerPress\ThirdParty\Faker\Provider\fr_CH;

class Color extends \FakerPress\ThirdParty\Faker\Provider\fr_FR\Color
{
}
