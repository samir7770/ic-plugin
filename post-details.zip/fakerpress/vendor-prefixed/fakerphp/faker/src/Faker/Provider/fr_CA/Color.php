<?php

namespace FakerPress\ThirdParty\Faker\Provider\fr_CA;

class Color extends \FakerPress\ThirdParty\Faker\Provider\fr_FR\Color
{
}
