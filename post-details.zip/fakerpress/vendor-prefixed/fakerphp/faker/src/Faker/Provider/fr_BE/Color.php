<?php

namespace FakerPress\ThirdParty\Faker\Provider\fr_BE;

class Color extends \FakerPress\ThirdParty\Faker\Provider\fr_FR\Color
{
}
