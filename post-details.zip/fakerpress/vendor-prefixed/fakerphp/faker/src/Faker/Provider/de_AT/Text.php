<?php

namespace FakerPress\ThirdParty\Faker\Provider\de_AT;

class Text extends \FakerPress\ThirdParty\Faker\Provider\de_DE\Text
{
}
