<?php

namespace FakerPress\ThirdParty\Faker\Provider\fr_CH;

class Text extends \FakerPress\ThirdParty\Faker\Provider\fr_FR\Text
{
}
