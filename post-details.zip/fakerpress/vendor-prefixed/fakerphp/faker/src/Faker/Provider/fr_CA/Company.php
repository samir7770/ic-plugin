<?php

namespace FakerPress\ThirdParty\Faker\Provider\fr_CA;

class Company extends \FakerPress\ThirdParty\Faker\Provider\fr_FR\Company
{
}
