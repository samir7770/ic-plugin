<?php

namespace FakerPress\ThirdParty\Faker\Provider\it_CH;

class Text extends \FakerPress\ThirdParty\Faker\Provider\it_IT\Text
{
}
