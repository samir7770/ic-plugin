<?php

namespace FakerPress\ThirdParty\Faker\Container;

use FakerPress\ThirdParty\Psr\Container\ContainerInterface as BaseContainerInterface;

interface ContainerInterface extends BaseContainerInterface
{
}
